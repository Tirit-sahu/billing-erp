<?php $__env->startSection('content'); ?>
    
<div class="page-content">

    <!-- Page title -->
    <div class="page-title">
        <h5><i class="fa fa-table"></i> Categories </h5>        
    </div>
    <!-- /page title -->

    
    <!-- Statistics -->
    <ul class="row stats">
        <li class="col-xs-3"><a href="#" class="btn btn-default">52</a> <span> Active</span></li>
        <li class="col-xs-3"><a href="#" class="btn btn-default">520</a> <span>In-Active</span></li>
        <li class="col-xs-3"></li>
        <li class="col-xs-3">
            <a href="" class="btn btn-info">ADD NEW CATEGORY</a>
        </li>
    </ul>
    <!-- /statistics -->



    <div class="panel panel-default">
        <div class="panel-heading"><h6 class="panel-title">Table elements</h6></div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>SNO.</th>
                        <th>Category</th>
                        <th>Option</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="text-center">
                            1
                        <td>
                            Mouse
                        </td>
                        <td>
                            <div >
                                <a href="#" class="btn btn-default btn-icon btn-xs tip" title="Delete entry"><i class="fa fa-minus"></i></a>
                                <a href="#" class="btn btn-default btn-icon btn-xs tip" title="Edit entry"><i class="fa fa-pencil"></i></a>
                            </div>
                        </td>
                    </tr>
                   
                </tbody>
            </table>
        </div>
    </div>





    <!-- Footer -->
    <div class="footer">
        &copy; Copyright 2011. All rights reserved. It's Brain admin theme by <a href="#" title="">Eugene Kopyov</a>
    </div>
    <!-- /footer -->


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/mohan-ent/resources/views/categories.blade.php ENDPATH**/ ?>