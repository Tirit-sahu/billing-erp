<div>
   <?php if(session()->has('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session()->get('success')); ?>

    </div>
   <?php elseif(session()->has('error')): ?>
   <div class="alert alert-danger" role="alert">
   <?php echo e(session()->get('error')); ?>

   </div>
   <?php endif; ?>

   <?php if($errors->any()): ?>

           
             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="alert alert-danger" role="alert"><?php echo e($error); ?></div>
                 <?php break; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
   <?php endif; ?>


</div>
<?php /**PATH /opt/lampp/htdocs/mohan-ent/resources/views/components/alert.blade.php ENDPATH**/ ?>