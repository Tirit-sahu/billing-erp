<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dashboard</title>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link href="<?php echo e(asset('public/cdn/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/cdn/css/brain-theme.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/cdn/css/styles.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/cdn/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
<link href='https://fonts.googleapis.com/css?family=Cuprum' rel='stylesheet' type='text/css'>

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js"></script>

<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/charts/flot.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/charts/flot.orderbars.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/charts/flot.pie.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/charts/flot.time.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/charts/flot.animator.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/charts/excanvas.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/charts/flot.resize.min.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/forms/uniform.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/forms/select2.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/forms/inputmask.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/forms/autosize.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/forms/inputlimit.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/forms/listbox.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/forms/multiselect.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/forms/validate.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/forms/tags.min.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/forms/uploader/plupload.full.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/forms/uploader/plupload.queue.min.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/forms/wysihtml5/wysihtml5.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/forms/wysihtml5/toolbar.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/interface/jgrowl.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/interface/datatables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/interface/prettify.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/interface/fancybox.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/interface/colorpicker.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/interface/timepicker.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/interface/fullcalendar.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/plugins/interface/collapsible.min.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/application.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('public/cdn/js/charts/simple_graph.js')); ?>"></script>

<style>
    .select-search{
        width: 100%!important;
    }
</style>

</head>

<body>

    <!-- Navbar -->
    <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container-fluid">
            <div class="navbar-header">
                <div class="hidden-lg pull-right">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-right">
                        <span class="sr-only">Toggle navigation</span>
                        <i class="fa fa-chevron-down"></i>
                    </button>

                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar">
                        <span class="sr-only">Toggle sidebar</span>
                        <i class="fa fa-bars"></i>
                    </button>
                </div>

                <ul class="nav navbar-nav navbar-left-custom">
                    <li class="user dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown">
                            <img src="<?php echo e(asset('public/cdn/images/demo/users/face6.png')); ?>" alt="">
                            <span>Eugene Kopyov</span>
                            <i class="caret"></i>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="#"><i class="fa fa-user"></i> Profile</a></li>
                            <li><a href="#"><i class="fa fa-tasks"></i> Tasks</a></li>
                            <li><a href="#"><i class="fa fa-cog"></i> Settings</a></li>
                            <li><a href="<?php echo e(route('user.logout')); ?>"><i class="fa fa-mail-forward"></i> Logout</a></li>
                        </ul>
                    </li>
                    <li><a class="nav-icon sidebar-toggle"><i class="fa fa-bars"></i></a></li>
                </ul>
            </div>

            <ul class="nav navbar-nav navbar-right collapse" id="navbar-right">
                <li>
                    <a href="#">
                        <i class="fa fa-rotate-right"></i>
                        <span>Updates</span>
                        <strong class="label label-danger">15</strong>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <i class="fa fa-comments"></i>
                        <span>Messages</span>
                        <strong class="label label-danger">7</strong>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <i class="fa fa-tasks"></i>
                        <span>Notifications</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <!-- /navbar -->


    <!-- Switches -->
    <div class="color-switch">
        <a href="https://demo.interface.club/itsbrain/liquid/dark/index.html" title="Switch to dark verion"></a>
    </div>

    <div class="layout-switch">
        <a href="https://demo.interface.club/itsbrain/fixed/light/index.html" title="Switch to fixed verion"></a>
    </div>
    <!-- /switches -->


    <!-- Page header -->
    <div class="container-fluid">
        <div class="page-header">
            <div class="logo"><a href="index-2.html" title=""><img src="<?php echo e(asset('public/cdn/images/logo.png')); ?>" alt=""></a></div>
            <ul class="middle-nav">
                <li><a href="#" class="btn btn-default"><i class="fa fa-comments-o"></i> <span>Support tickets</span></a><div class="label label-info">9</div></li>
                <li><a href="#" class="btn btn-default"><i class="fa fa-bars"></i> <span>Statistics</span></a></li>
                <li><a href="#" class="btn btn-default"><i class="fa fa-male"></i> <span>User list</span></a></li>
                <li><a href="#" class="btn btn-default"><i class="fa fa-money"></i> <span>Billing panel</span></a></li>
            </ul>
        </div>
    </div>
    <!-- /page header -->


    <!-- Page container -->
    <div class="page-container container-fluid">
    	
    	<!-- Sidebar -->
        <div class="sidebar collapse">
        	<ul class="navigation">
            	<li class="active"><a href="index-2.html"><i class="fa fa-laptop"></i> Dashboard</a></li>
               <li>
                    <a href="#" class="expand"><i class="fa fa-align-justify"></i> Master</a>
                    <ul>
                        <li><a href="<?php echo e(route('company.index')); ?>">Add Company</a></li>
                        <li><a href="<?php echo e(route('session.index')); ?>">Add Session</a></li>
                        <li><a href="<?php echo e(route('category.index')); ?>">Add Category</a></li>
                        <li><a href="<?php echo e(route('sub-category.index')); ?>">Add Sub Category</a></li>
                        <li><a href="<?php echo e(route('unit.index')); ?>">Add Unit</a></li>
                        <li><a href="<?php echo e(route('product.index')); ?>">Add Product</a></li>
                        <li><a href="<?php echo e(route('head.index')); ?>">Add Head</a></li>
                        <li><a href="<?php echo e(route('party.index')); ?>">Party</a></li>
                        
                     </ul>
                </li>


                <li>
                    <a href="<?php echo e(route('purchase.index')); ?>"><i class="fa fa-align-justify"></i> Purchase</a>
                </li>

                <li>
                    <a href="<?php echo e(route('sales.index')); ?>"><i class="fa fa-align-justify"></i> Sales</a>
                </li>
                
                
          
            </ul>
        </div>
        <!-- /sidebar -->

    
        <!-- Page content -->
        <?php echo $__env->yieldContent('content'); ?>
        
    </div>

</body>

</html>
<?php /**PATH /opt/lampp/htdocs/mohan-ent/resources/views/layout/app.blade.php ENDPATH**/ ?>