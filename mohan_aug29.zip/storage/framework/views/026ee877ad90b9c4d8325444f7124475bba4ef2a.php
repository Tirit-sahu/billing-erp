<?php $__env->startSection('content'); ?>

<div class="page-content">

    <!-- Page title -->
    <div class="page-title">
        <h5><i class="fa fa-align-justify"></i> Add Product</h5>
    </div>
    <!-- /page title -->


    <!-- Advanced form components -->
    

        <!-- HTML5 inputs -->
        <div class="panel panel-default">
            <div class="panel-heading"><h6 class="panel-title">Add Product</h6></div>
            <div class="panel-body">
             <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php if(isset($data)): ?>

            <form action="<?php echo e(route('product.update',$data->id )); ?>" class="form-horizontal" method="post" >
            <?php echo method_field('PATCH'); ?>;

            <?php else: ?>
            <form action="<?php echo e(route('product.store')); ?>" class="form-horizontal" method="post" >
            <?php endif; ?>
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label class="col-sm-2 control-label">Category Name : </label>
                    <div class="col-sm-10">
                            <select data-placeholder="Choose a Category..." class="select-search" name="category_id" id="category_id" required tabindex="2">
                                <option value=""></option> 
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cate->id); ?>"><?php echo e($cate->name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <script>document.getElementById("category_id").value = "<?php echo e(old('category_id',isset($data->category_id) ? $data->category_id : '' )); ?>"; </script>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-2 control-label">Sub Category Name : </label>
                    <div class="col-sm-10">
                            <select data-placeholder="Choose a Category..." class="select-search" name="sub_category_id" id="sub_category_id" required tabindex="2">
                                <option value=""></option> 
                                <?php $__currentLoopData = $subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cate->id); ?>"><?php echo e($cate->name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <script>document.getElementById("sub_category_id").value = "<?php echo e(old('sub_category_id',isset($data->sub_category_id) ? $data->sub_category_id : '' )); ?>"; </script>
                    </div>
                </div>


                <div class="form-group">
                    <label class="col-sm-2 control-label">Unit Name : </label>
                    <div class="col-sm-10">
                            <select data-placeholder="Choose a Category..." class="select-search" name="unit_id" id="unit_id" required tabindex="2">
                                <option value=""></option> 
                                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cate->id); ?>"><?php echo e($cate->name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <script>document.getElementById("unit_id").value = "<?php echo e(old('unit_id',isset($data->unit_id) ? $data->unit_id : '' )); ?>"; </script>
                    </div>
                </div>
                

                <div class="form-group">
                    <label class="col-sm-2 control-label">Product Name : </label>
                    <div class="col-sm-10">
                        <input class="form-control" type="text" name="name" value="<?php echo e(old('name',isset($data->name) ? $data->name : '' )); ?>">
                    </div>
                </div>


                <div class="form-group">
                    <label class="col-sm-2 control-label">Price : </label>
                    <div class="col-sm-10">
                        <input class="form-control" type="text" name="price" value="<?php echo e(old('price',isset($data->price) ? $data->price : '' )); ?>">
                    </div>
                </div>


                <div class="form-group">
                    <label class="col-sm-2 control-label">Status: </label>
                    <div class="col-sm-10">
                        <div class="widget-inner">
                            <label class="checkbox-inline">
                                <input type="checkbox"  class="styled" <?php if(isset($data)): ?> <?php if($data->status==1): ?> checked  <?php endif; ?> <?php endif; ?> name="status">
                                Active
                            </label>

                        </div>
                    </div>
                </div>

                <div class="form-actions pull-right">
                    <a href="<?php echo e(route('product.index')); ?>" class="btn btn-danger">Back </a>
                    <input type="submit" value="<?php echo e(isset($data) ? 'Update' : 'Submit'); ?>" class="btn btn-primary">
                </div>
            </form>
            </div>
        </div>
        <!-- /HTML5 inputs -->

    


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/mohan-ent/resources/views/product/product.blade.php ENDPATH**/ ?>