<?php $__env->startSection('content'); ?>

<?php 
use \App\Http\Controllers\CommonController;
use Illuminate\Http\Request;
?>
<div class="page-content">

    <!-- Page title -->
    <div class="page-title">
        <h5><i class="fa fa-table"></i> Purchase </h5>        
    </div>
    <!-- /page title -->

    
    <!-- Statistics -->
    <ul class="row stats">
        <li class="col-xs-3"><a href="#" class="btn btn-default">52</a> <span> Active</span></li>
        <li class="col-xs-3"><a href="#" class="btn btn-default">520</a> <span>In-Active</span></li>
        <li class="col-xs-3"></li>
        <li class="col-xs-3">
            <a href="<?php echo e(route('purchase.create')); ?>" class="btn btn-info">Purchase Entry</a>
        </li>
    </ul>
    <!-- /statistics -->

 <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

    <div class="panel panel-default">
        <div class="panel-heading"><h6 class="panel-title">Table elements</h6></div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>SNO.</th>
                        <th>Party Name</th>
                        <th>purchase Date</th>
                        <th>Total Amount</th>
                        <th>Option</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    
                        <td class="text-center">
                            <?php echo e($loop->index+1); ?>

                        <td>
                            <?php echo e($row->party->name); ?>

                        </td>

                        <td>
                            <?php echo e(date('d-m-Y', strtotime($row->date))); ?>

                        </td>

                        <td>
                            <?php echo e(CommonController::getTotalAmount($row->id)); ?>

                        </td>                                                
                        
                       

                        <td>
                            <div >

                            <a href="<?php echo e(url('purchase-details')); ?>?purchase_id=<?php echo e($row->id); ?>" class="btn btn-default btn-icon btn-xs tip" rel="tooltip" title="View">
                            <i class="fa fa-eye" aria-hidden="true"></i>
                            </a>

                            <a href="<?php echo e(url('purchase-edit/'.$row->id)); ?>" class="btn btn-default btn-icon btn-xs tip" rel="tooltip" title="Edit">
                            <i class="fa fa-pencil"></i>
                            </a>                            
                            
                            <a href="#" class="btn" rel="tooltip" title="Delete">
                                                                
                                <form action="<?php echo e(route('party.destroy',$row->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-default btn-icon btn-xs tip">
                                        <i class="fa fa-minus" onclick="return confirm('Are you sure to Delete?')"></i>
                                    </button>
                                </form>
                            </a>

                            </div>
                        </td>
                    </tr>

                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                   
                </tbody>
            </table>
        </div>
    </div>






</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/mohan-ent/resources/views/purchase/purchaseView.blade.php ENDPATH**/ ?>