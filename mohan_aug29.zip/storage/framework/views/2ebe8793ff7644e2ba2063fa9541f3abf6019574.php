<?php $__env->startSection('content'); ?>

<div class="page-content">

    <!-- Page title -->
    <div class="page-title">
        <h5><i class="fa fa-align-justify"></i> Add Categories</h5>
    </div>
    <!-- /page title -->


    <!-- Advanced form components -->
    

        <!-- HTML5 inputs -->
        <div class="panel panel-default">
            <div class="panel-heading"><h6 class="panel-title">Add Session</h6></div>
            <div class="panel-body">
             <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php if(isset($data)): ?>
            <form action="<?php echo e(route('session.update',$data->id )); ?>" class="form-horizontal" method="post" >
            <?php echo method_field('PATCH'); ?>;
            <?php else: ?>
            <form action="<?php echo e(route('session.store')); ?>" class="form-horizontal" method="post" >
            <?php endif; ?>
                <?php echo csrf_field(); ?>
        

                <div class="form-group">
                    <label class="col-sm-2 control-label">Start Date : </label>
                    <div class="col-sm-6">
                        <input class="form-control" type="date" name="startDate" value="<?php echo e(old('startDate',isset($data->startDate) ? $data->startDate : '' )); ?>">
                    </div>
                </div>


                <div class="form-group">
                    <label class="col-sm-2 control-label">End Date : </label>
                    <div class="col-sm-6">
                        <input class="form-control" type="date" name="endDate" value="<?php echo e(old('endDate',isset($data->endDate) ? $data->endDate : '' )); ?>">
                    </div>
                </div>


                <div class="form-group">
                    <label class="col-sm-2 control-label">Session Name : </label>
                    <div class="col-sm-6">
                        <input class="form-control" type="text" name="name" value="<?php echo e(old('name',isset($data->name) ? $data->name : '' )); ?>">
                    </div>
                </div>


                <div class="form-group">
                    <label class="col-sm-2 control-label">Sale Invoice Prefix : </label>
                    <div class="col-sm-6">
                        <input class="form-control" type="text" name="saleInvoicePrefix" value="<?php echo e(old('saleInvoicePrefix',isset($data->saleInvoicePrefix) ? $data->saleInvoicePrefix : '' )); ?>">
                    </div>
                </div>


                <div class="form-group">
                    <label class="col-sm-2 control-label">Purchase Invoice Prefix : </label>
                    <div class="col-sm-6">
                        <input class="form-control" type="text" name="purchaseInvoicePrefix" value="<?php echo e(old('purchaseInvoicePrefix',isset($data->purchaseInvoicePrefix) ? $data->purchaseInvoicePrefix : '' )); ?>">
                    </div>
                </div>

          
                <div class="form-actions">
                    <a href="<?php echo e(route('category.index')); ?>" class="btn btn-danger">Back </a>
                    <input type="submit" value="<?php echo e(isset($data) ? 'Update' : 'Submit'); ?>" class="btn btn-primary">
                </div>
            </form>
            </div>
        </div>
        <!-- /HTML5 inputs -->

    


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/mohan-ent/resources/views/session/session.blade.php ENDPATH**/ ?>